#!/bin/bash
# ADA ALLOY - macOS installer (double-click in Finder; a Terminal window opens)
# Copies the plug-in (VST3 + Audio Unit) to /Library/Audio/Plug-Ins and removes the download
# quarantine so macOS lets your DAW load it. Asks for your Mac password once.
cd "$(dirname "$0")" || exit 1
echo "ADA ALLOY - installing VST3 + Audio Unit"
echo "macOS will ask for your password (nothing is shown while you type)."
echo

VST3_DIR="/Library/Audio/Plug-Ins/VST3"
AU_DIR="/Library/Audio/Plug-Ins/Components"
sudo mkdir -p "$VST3_DIR" "$AU_DIR" || exit 1

P="ADA ALLOY"
sudo rm -rf "$VST3_DIR/$P.vst3" "$AU_DIR/$P.component"
sudo ditto "VST3/$P.vst3"            "$VST3_DIR/$P.vst3"
sudo ditto "Components/$P.component" "$AU_DIR/$P.component"
sudo xattr -rd com.apple.quarantine "$VST3_DIR/$P.vst3"    2>/dev/null
sudo xattr -rd com.apple.quarantine "$AU_DIR/$P.component" 2>/dev/null
echo "  installed: $P (VST3 + Audio Unit)"

killall -9 AudioComponentRegistrar >/dev/null 2>&1   # DAWs see the new Audio Unit without a restart
echo
echo "Done. Open your DAW and rescan plug-ins, then insert ADA ALLOY on a track or bus."
echo "You can close this window."
