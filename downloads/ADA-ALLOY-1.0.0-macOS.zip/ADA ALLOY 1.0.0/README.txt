ADA ALLOY 1.0.0  -  macOS
Anima Digital Audio  |  https://animadigitalaudio.com/alloy.html

INSTALL
  1. Double-click "Install ADA ALLOY.command".
     If macOS says it cannot be opened: right-click it > Open > Open.
  2. Enter your Mac password when asked (nothing is shown while you type).
  3. Open your DAW and rescan plug-ins. ADA ALLOY is listed under "Anima Digital Audio".

  The installer copies
    /Library/Audio/Plug-Ins/VST3/ADA ALLOY.vst3
    /Library/Audio/Plug-Ins/Components/ADA ALLOY.component   (Audio Unit: Logic, GarageBand, ...)
  Universal: Apple Silicon and Intel Macs, macOS 10.13 or newer.

MANUAL INSTALL (if you prefer)
  Copy the folders yourself, then run in Terminal:
    sudo xattr -rd com.apple.quarantine "/Library/Audio/Plug-Ins/VST3/ADA ALLOY.vst3" "/Library/Audio/Plug-Ins/Components/ADA ALLOY.component"

TRIAL AND ACTIVATION
  ADA ALLOY starts as a full trial with 60 minutes of playing time (only the time sound
  actually runs through it counts). When it is used up the plug-in is bypassed.
  To buy: click TRIAL at the top of the plug-in > BUY ADA ALLOY. To activate: enter your
  name and the license key from your purchase e-mail and press ACTIVATE - it unlocks at
  once, no restart. Without internet on this Mac: press COPY next to the Hardware ID, enter
  key + ID at animadigitalaudio.com/activate.html on any device and load the license.lic
  you receive (LOAD LICENSE FILE...). No account, no iLok.

  License and trial data: ~/Library/Application Support/Anima Digital Audio/ADA ALLOY/
