#!/bin/bash
# Easy Wizard - macOS installer (double-click in Finder; a Terminal window opens)
# Copies both plug-ins (VST3 + Audio Unit) to /Library/Audio/Plug-Ins, the standalone app to
# /Applications, and removes the
# download quarantine so macOS lets your DAW load them. Asks for your Mac password once.
cd "$(dirname "$0")" || exit 1
echo "Easy Wizard - installing VST3 + Audio Unit (Synth and Fx) + standalone app"
echo "macOS will ask for your password (nothing is shown while you type)."
echo

VST3_DIR="/Library/Audio/Plug-Ins/VST3"
AU_DIR="/Library/Audio/Plug-Ins/Components"
sudo mkdir -p "$VST3_DIR" "$AU_DIR" || exit 1

for P in "Easy Wizard (Synth)" "Easy Wizard (Fx)"; do
    sudo rm -rf "$VST3_DIR/$P.vst3" "$AU_DIR/$P.component"
    sudo ditto "VST3/$P.vst3"            "$VST3_DIR/$P.vst3"
    sudo ditto "Components/$P.component" "$AU_DIR/$P.component"
    sudo xattr -rd com.apple.quarantine "$VST3_DIR/$P.vst3"      2>/dev/null
    sudo xattr -rd com.apple.quarantine "$AU_DIR/$P.component"   2>/dev/null
    echo "  installed: $P"
done
# standalone app (play Easy Wizard (Synth) without a DAW)
APP="Easy Wizard (Synth).app"
if [[ -d "Applications/$APP" ]]; then
    sudo rm -rf "/Applications/$APP"
    sudo ditto "Applications/$APP" "/Applications/$APP"
    sudo xattr -rd com.apple.quarantine "/Applications/$APP" 2>/dev/null
    echo "  installed: /Applications/$APP"
fi
# builds released under an earlier name
sudo rm -rf "$VST3_DIR/Easy Wizard Fx.vst3" "$VST3_DIR/Easy Wizard Fx FX.vst3" \
            "$AU_DIR/Easy Wizard Fx.component" "$AU_DIR/Easy Wizard Fx FX.component"

killall -9 AudioComponentRegistrar >/dev/null 2>&1   # DAWs see the new Audio Units without a restart
echo
echo "Done. Open your DAW and rescan plug-ins, or start Easy Wizard (Synth) from Applications."
echo "You can close this window."
