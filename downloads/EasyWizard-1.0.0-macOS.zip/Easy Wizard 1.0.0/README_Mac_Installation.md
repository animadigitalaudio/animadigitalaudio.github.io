# Easy Wizard 1.0.0 for macOS – Installation

**Anima Digital Audio**

This download contains two plug-ins, each as **VST3** and **Audio Unit (AU)**:

| Plug-in | What it is | VST3 | Audio Unit |
|---|---|---|---|
| **Easy Wizard (Synth)** | Instrument: load a sample and play it with MIDI | `VST3/Easy Wizard (Synth).vst3` | `Components/Easy Wizard (Synth).component` |
| **Easy Wizard (Fx)** | Audio effect: insert it on any track (with sidechain input) | `VST3/Easy Wizard (Fx).vst3` | `Components/Easy Wizard (Fx).component` |

Plus a **standalone app** – `Applications/Easy Wizard (Synth).app` – to play the Synth without a DAW
(copy it to your Applications folder; the automatic installer does this for you).

- Runs natively on **Apple Silicon (M1 / M2 / M3 / M4)** and **Intel** Macs (Universal Binary, no Rosetta needed).
- Requires **macOS 10.13** or newer and a 64-bit host (Logic Pro, Ableton Live, FL Studio, Reaper, Cubase, Studio One, Bitwig, GarageBand…).
- Logic Pro and GarageBand use the **Audio Unit**; most other DAWs use the **VST3**. Installing both is fine.

> **Why the extra step?** Easy Wizard is not distributed through the Mac App Store or Apple's paid
> notarization service, so macOS marks the downloaded files as "quarantined" and may say that the
> plug-in *"is damaged and can't be opened"* or *"cannot be verified"*. The files are fine: removing
> the quarantine flag once (below) tells macOS that you trust them.

---

## Option A – Automatic install (recommended)

1. Unzip `EasyWizard-1.0.0-macOS.zip` (double-click it).
2. Open the folder **Easy Wizard 1.0.0** and double-click **`Install Easy Wizard.command`**.
3. A Terminal window opens and asks for your **Mac login password** (nothing is shown while you type – that is normal). Press **Return**.
4. When it says **Done**, close the window and open your DAW.

**If macOS refuses to open `Install Easy Wizard.command`:**

- **Right-click** (or Control-click) the file → **Open** → **Open**, or
- open **System Settings → Privacy & Security**, scroll down and click **Open Anyway**, or
- open **Terminal** (Applications → Utilities), type `bash ` (with a space), drag the file into the Terminal window and press **Return**.

---

## Option B – Manual install with Terminal

### 1. Copy the plug-ins

Open **Finder → Go → Go to Folder…** (⇧⌘G) and copy:

- the two **`.vst3`** files from the `VST3` folder to **`/Library/Audio/Plug-Ins/VST3/`**
- the two **`.component`** files from the `Components` folder to **`/Library/Audio/Plug-Ins/Components/`**

(Finder asks for your password because these are system-wide folders.)

### 2. Remove the quarantine

Open **Terminal** (Applications → Utilities → Terminal), paste the following block and press **Return**.
Enter your Mac password when asked (it is not displayed while you type).

```bash
sudo xattr -rd com.apple.quarantine "/Library/Audio/Plug-Ins/VST3/Easy Wizard (Synth).vst3"
sudo xattr -rd com.apple.quarantine "/Library/Audio/Plug-Ins/VST3/Easy Wizard (Fx).vst3"
sudo xattr -rd com.apple.quarantine "/Library/Audio/Plug-Ins/Components/Easy Wizard (Synth).component"
sudo xattr -rd com.apple.quarantine "/Library/Audio/Plug-Ins/Components/Easy Wizard (Fx).component"
killall -9 AudioComponentRegistrar 2>/dev/null; echo "Easy Wizard: done"
```

The quotes are required because the file names contain spaces and brackets.
If you installed only some of the plug-ins, a line for a missing file prints *"No such file"* – that is harmless.

### Installing for your user account only (no administrator rights)

Copy the files to the `Library` folder in your home folder instead
(`~/Library/Audio/Plug-Ins/VST3/` and `~/Library/Audio/Plug-Ins/Components/`), then run:

```bash
xattr -rd com.apple.quarantine ~/Library/Audio/Plug-Ins/VST3/"Easy Wizard (Synth).vst3" ~/Library/Audio/Plug-Ins/VST3/"Easy Wizard (Fx).vst3"
xattr -rd com.apple.quarantine ~/Library/Audio/Plug-Ins/Components/"Easy Wizard (Synth).component" ~/Library/Audio/Plug-Ins/Components/"Easy Wizard (Fx).component"
killall -9 AudioComponentRegistrar 2>/dev/null
```

---

## 3. Let your DAW find the plug-ins

| DAW | What to do |
|---|---|
| **Logic Pro / GarageBand** | Restart the app. If Easy Wizard is missing: Logic Pro → Settings → Plug-in Manager → select it → **Reset & Rescan Selection**. Instrument: *AU Instruments → Anima Digital Audio*; effect: *Audio FX → Anima Digital Audio*. |
| **Ableton Live** | Settings → Plug-Ins → turn on *Use VST3 Plug-In System Folders* (and *Use Audio Units v2*) → **Rescan**. |
| **FL Studio** | Options → Manage plugins → **Find installed plugins**. |
| **Reaper** | Settings → Plug-ins → VST → **Re-scan**. |
| **Cubase / Nuendo** | Studio → VST Plug-in Manager → **Rescan All**. |
| **Studio One / Bitwig** | Restart the app (or rescan in the plug-in settings). |

---

## 4. Trial and activation

Both plug-ins start as a **full 14-day trial**. To activate:

1. Open the plug-in and click the **TRIAL MODE** badge under the title.
2. Press **COPY** next to *Your Hardware ID* and send it to us with your order number.
3. You receive your personal `license.lic` file by e-mail.
4. Click **LOAD LICENSE FILE…** and choose it (or paste its text).

One license activates both Easy Wizard (Synth) and Easy Wizard (Fx) on your Mac.
Activation works offline — no account, no internet connection, no iLok.

---

## Troubleshooting

- **"… is damaged and can't be opened" / "cannot be verified" / the DAW skips the plug-in**
  The quarantine is still set – run the Terminal block from step 2 again, then restart the DAW.
- **Audio Unit doesn't appear in Logic**
  Run `killall -9 AudioComponentRegistrar` in Terminal, then rescan in the Plug-in Manager.
  You can test the Audio Units with:
  `auval -v aumu Ewfx Anim` (Synth) and `auval -v aumf Ewfe Anim` (Fx) – the last line should read *AU VALIDATION SUCCEEDED*.
- **Plug-in listed twice**
  You may still have an older copy in `~/Library/Audio/Plug-Ins/…` as well as `/Library/Audio/Plug-Ins/…`. Delete one of them.
- **Older test version "Easy Wizard Fx" is still installed**
  Delete `Easy Wizard Fx.vst3`, `Easy Wizard Fx FX.vst3`, `Easy Wizard Fx.component` and `Easy Wizard Fx FX.component` from the Plug-Ins folders (the automatic installer does this for you). Your presets and license are kept.

## Uninstall

```bash
sudo rm -rf "/Library/Audio/Plug-Ins/VST3/Easy Wizard (Synth).vst3" "/Library/Audio/Plug-Ins/VST3/Easy Wizard (Fx).vst3"
sudo rm -rf "/Library/Audio/Plug-Ins/Components/Easy Wizard (Synth).component" "/Library/Audio/Plug-Ins/Components/Easy Wizard (Fx).component"
sudo rm -rf "/Applications/Easy Wizard (Synth).app"
```

Your presets, renders and license stay in `~/Library/Application Support/Anima Digital Audio/Easy Wizard/`
and `~/Documents/Easy Wizard/` – delete those folders too if you want to remove everything.

---

Questions or problems? Write to **support@animadigitalaudio.com** (https://animadigitalaudio.com) – please include your macOS version, Mac model (Intel or Apple Silicon) and DAW.
